# Bingo_Online
Este código é uma página HTML simples que permite ao usuário inserir nomes de pessoas em um formulário de texto e, em seguida, clicar em um botão "Sortear" para selecionar aleatoriamente uma dessas pessoas.

A página inclui uma seção de cabeçalho com o título "Sorteio de Pessoas", um formulário com um campo de entrada de texto para nomes de pessoas e um botão de "Sortear", e uma seção de resultado onde o nome da pessoa selecionada aleatoriamente será exibido.

O código também inclui um link para um arquivo de estilo CSS externo chamado "style.css" e um arquivo JavaScript externo chamado "script.js", que contém a função "sortear()" responsável por selecionar aleatoriamente uma das pessoas inseridas no formulário e exibi-la na seção de resultado da página.

Por fim, há uma seção de rodapé com o nome do desenvolvedor "Sandro".

https://www.youtube.com/watch?v=NClT0zyRBRE
